#!/bin/sh
java -jar ../decaf.jar $1 -l 4 > $2.s
